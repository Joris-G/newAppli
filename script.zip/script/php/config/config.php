<?php
//Les différentes connexions aux bases SQL
$DataDb = [];

$DataDb[0] = ['DB_HOST' => 'localhost:3306', 'DB_LOGIN' => 'root', 'DB_PASS' => '', 'DB_BASE' => 'tracadev'];
$DataDb[1] = ['DB_HOST' => 'localhost:3308', 'DB_LOGIN' => 'root', 'DB_PASS' => '', 'DB_BASE' => 'tracadev'];
$DataDb[2] = ['DB_HOST' => 'localhost:3306', 'DB_LOGIN' => 'root', 'DB_PASS' => 'root', 'DB_BASE' => 'tracadev'];
